/* ═══════════════════════════════════════════
   Wall Painting BD — Main JavaScript
   ═══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', function() {

  /* ── Sticky Header ── */
  const header = document.querySelector('header');
  window.addEventListener('scroll', function() {
    if (window.scrollY > 20) { header.classList.add('scrolled'); }
    else { header.classList.remove('scrolled'); }
  });

  /* ── Mobile Menu ── */
  const menuBtn = document.getElementById('menu-toggle');
  const mobileNav = document.getElementById('mobile-nav');
  if (menuBtn && mobileNav) {
    menuBtn.addEventListener('click', function() {
      mobileNav.classList.toggle('open');
      const icon = menuBtn.querySelector('svg use');
      if (mobileNav.classList.contains('open')) {
        menuBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
      } else {
        menuBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>';
      }
    });
  }

  /* ── Desktop Dropdown ── */
  const dropdown = document.querySelector('.dropdown');
  if (dropdown) {
    dropdown.addEventListener('click', function(e) {
      e.stopPropagation();
      dropdown.classList.toggle('open');
    });
    document.addEventListener('click', function() { dropdown.classList.remove('open'); });
  }

  /* ── Hero Slider ── */
  const slides = document.querySelectorAll('.hero-slide');
  const dots = document.querySelectorAll('.hero-dot');
  const heroTitle = document.getElementById('hero-title');
  const heroSubtitle = document.getElementById('hero-subtitle');
  let currentSlide = 0;

  const heroData = [
    { title: 'Transform Your Walls Into <span class="accent">Art</span>', subtitle: 'Professional wall painting services for homes, offices & restaurants in Bangladesh' },
    { title: 'Bring <span class="accent">Colors</span> To Your Space', subtitle: 'Custom murals and wall art that tell your unique story with vibrant creativity' },
    { title: 'Elevate Your <span class="accent">Brand</span> With Wall Art', subtitle: 'Office branding, restaurant walls & commercial spaces designed to impress' },
  ];

  function showSlide(n) {
    slides.forEach(function(s, i) { s.classList.toggle('active', i === n); });
    dots.forEach(function(d, i) { d.classList.toggle('active', i === n); });
    if (heroTitle) { heroTitle.innerHTML = heroData[n].title; }
    if (heroSubtitle) { heroSubtitle.textContent = heroData[n].subtitle; }
    currentSlide = n;
  }

  if (slides.length > 0) {
    setInterval(function() { showSlide((currentSlide + 1) % slides.length); }, 6000);
    var prevBtn = document.getElementById('hero-prev');
    var nextBtn = document.getElementById('hero-next');
    if (prevBtn) prevBtn.addEventListener('click', function() { showSlide((currentSlide - 1 + slides.length) % slides.length); });
    if (nextBtn) nextBtn.addEventListener('click', function() { showSlide((currentSlide + 1) % slides.length); });
    dots.forEach(function(d, i) { d.addEventListener('click', function() { showSlide(i); }); });
  }

  /* ── FAQ Accordion ── */
  document.querySelectorAll('.faq-question').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var item = btn.closest('.faq-item');
      item.classList.toggle('open');
    });
  });

  /* ── Portfolio Filter ── */
  var filterBtns = document.querySelectorAll('.filter-btn');
  filterBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
      filterBtns.forEach(function(b) { b.classList.remove('active'); });
      btn.classList.add('active');
      var cat = btn.getAttribute('data-filter');
      document.querySelectorAll('.filterable').forEach(function(item) {
        if (cat === 'All' || item.getAttribute('data-cat') === cat) {
          item.style.display = '';
        } else {
          item.style.display = 'none';
        }
      });
    });
  });

  /* ── Gallery Lightbox ── */
  var galleryItems = document.querySelectorAll('.masonry-item');
  var lightbox = document.getElementById('lightbox');
  var lightboxImg = document.getElementById('lightbox-img');
  var lightboxCaption = document.getElementById('lightbox-caption');
  var currentLightbox = 0;
  var visibleItems = [];

  function updateVisibleItems() {
    visibleItems = [];
    galleryItems.forEach(function(item) {
      if (item.style.display !== 'none') visibleItems.push(item);
    });
  }

  function openLightbox(idx) {
    if (!lightbox) return;
    updateVisibleItems();
    currentLightbox = idx;
    var img = visibleItems[idx].querySelector('img');
    lightboxImg.src = img.src;
    lightboxImg.alt = img.alt;
    if (lightboxCaption) lightboxCaption.textContent = img.alt;
    lightbox.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    if (!lightbox) return;
    lightbox.style.display = 'none';
    document.body.style.overflow = '';
  }

  galleryItems.forEach(function(item, i) {
    item.addEventListener('click', function() { openLightbox(i); });
  });

  if (lightbox) {
    document.getElementById('lightbox-close').addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', function(e) { if (e.target === lightbox) closeLightbox(); });
    var lbPrev = document.getElementById('lightbox-prev');
    var lbNext = document.getElementById('lightbox-next');
    if (lbPrev) lbPrev.addEventListener('click', function(e) { e.stopPropagation(); updateVisibleItems(); currentLightbox = (currentLightbox - 1 + visibleItems.length) % visibleItems.length; var img = visibleItems[currentLightbox].querySelector('img'); lightboxImg.src = img.src; lightboxImg.alt = img.alt; if (lightboxCaption) lightboxCaption.textContent = img.alt; });
    if (lbNext) lbNext.addEventListener('click', function(e) { e.stopPropagation(); updateVisibleItems(); currentLightbox = (currentLightbox + 1) % visibleItems.length; var img = visibleItems[currentLightbox].querySelector('img'); lightboxImg.src = img.src; lightboxImg.alt = img.alt; if (lightboxCaption) lightboxCaption.textContent = img.alt; });
  }

  /* ── Back to Top ── */
  var backToTop = document.getElementById('back-to-top');
  if (backToTop) {
    window.addEventListener('scroll', function() {
      if (window.scrollY > 400) { backToTop.classList.add('visible'); }
      else { backToTop.classList.remove('visible'); }
    });
    backToTop.addEventListener('click', function() { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  /* ── Scroll Reveal ── */
  var reveals = document.querySelectorAll('.reveal');
  function checkReveal() {
    reveals.forEach(function(el) {
      var top = el.getBoundingClientRect().top;
      if (top < window.innerHeight - 80) { el.classList.add('visible'); }
    });
  }
  window.addEventListener('scroll', checkReveal);
  checkReveal();

  /* ── Contact Form ── */
  var contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      var name = contactForm.querySelector('[name="name"]').value.trim();
      var phone = contactForm.querySelector('[name="phone"]').value.trim();
      var message = contactForm.querySelector('[name="message"]').value.trim();
      var valid = true;
      contactForm.querySelectorAll('.form-error').forEach(function(el) { el.textContent = ''; });
      if (!name) { document.getElementById('error-name').textContent = 'Name is required'; valid = false; }
      if (!phone) { document.getElementById('error-phone').textContent = 'Phone is required'; valid = false; }
      if (!message) { document.getElementById('error-message').textContent = 'Message is required'; valid = false; }
      if (valid) {
        contactForm.innerHTML = '<div style="text-align:center;padding:3rem 0"><div class="icon-wrap" style="width:4rem;height:4rem;background:hsl(var(--accent)/0.1);border-radius:9999px;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--accent))" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></div><h3 style="font-size:1.5rem;font-weight:800">Thank You!</h3><p style="color:hsl(var(--muted-foreground));margin-top:0.5rem">We\'ll get back to you soon.</p></div>';
      }
    });
  }

});
